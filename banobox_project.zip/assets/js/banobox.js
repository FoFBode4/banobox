// assets/js/banobox.js
// ====================
// Каталог + кошик + деталі + категорії/підкатегорії + ВАРІАНТИ (кольори)

window.productDetail = {
  current: {},
  recommendations: [],
  variants: [],
  selectedVolumeId: null,
  selectedColorId:  null,
  selectedMaterialId: null,
  quantity: 1,
};

let ALL_PRODUCTS = []; // кеш каталогу
let cart = getCart();




const COLOR_MAP = {
  'прозорий':'#f3f4f6','рожевий':'#f472b6','чорний':'#111827','білий':'#ffffff',
  'синій':'#2563eb','зелений':'#10b981','червоний':'#ef4444'
};
function pickColorHex(p){
  if (p.color_hex) return p.color_hex;
  const key = String(p.color||'').trim().toLowerCase();
  return COLOR_MAP[key] || null;
}


/* ──────────────────────────────
 * КОШИК
 * ────────────────────────────── */
function getCart() {
  try { return JSON.parse(localStorage.getItem('banobox_cart') || '[]') || []; }
  catch { return []; }
}
function setCart(arr) {
  cart = Array.isArray(arr) ? arr : [];
  localStorage.setItem('banobox_cart', JSON.stringify(cart));
  updateCartCount();
}
function updateCartCount() {
  const count = cart.reduce((s, i) => s + Number(i.quantity || 0), 0);
  document.querySelectorAll('.cart-count').forEach(el => el.textContent = count);
}
function calcUnitPrice(item) {
  const price = Number(item.price || 0);
  const discount = Number(item.discount || 0);
  return discount ? +(price * (100 - discount) / 100).toFixed(2) : +price.toFixed(2);
}
function cartKey({ pos, volume_id=null, color_id=null, material_id=null }) {
  return `${String(pos).toLowerCase()}|v:${volume_id ?? 'null'}|c:${color_id ?? 'null'}|m:${material_id ?? 'null'}`;
}
function addToCart(product, qty, opts = {}) {
  const quantity = Math.max(1, Number(qty || 1));
  const item = {
    pos:       product.pos,
    title:     product.title,
    price:     Number(product.price || 0),
    discount:  Number(product.discount || 0),
    photos:    Array.isArray(product.photos) ? product.photos : (product.photos ? [product.photos] : []),

    volume_id:    opts.volume_id    ?? product.volume_id ?? null,
    volume_ml:    opts.volume_ml    ?? product.ml        ?? null,
    volume_label: opts.volume_label ?? (product.volume || (product.ml ? `${product.ml} мл` : null)),
    color_id:     opts.color_id     ?? product.color_id  ?? null,
    color_name:   opts.color_name   ?? product.color     ?? null,
    material_id:  opts.material_id  ?? product.material_id ?? null,
    material_name:opts.material_name?? product.material  ?? null,

    volume: (opts.volume_label ?? product.volume ?? (product.ml ? `${product.ml} мл` : null)) || null,
    color:  (opts.color_name ?? product.color ?? null),
    quantity
  };

  const key = cartKey(item);
  const idx = cart.findIndex(i => cartKey(i) === key);
  if (idx > -1) cart[idx].quantity = Math.max(1, Number(cart[idx].quantity || 1) + quantity);
  else cart.push(item);
  setCart(cart);
}
function addCurrentProductToCart(qty) {
  const p = window.productDetail.current || {};
  const opts = {
    volume_id:     window.productDetail.selectedVolumeId ?? p.volume_id ?? null,
    volume_ml:     p.ml ?? null,
    volume_label:  p.volume ?? (p.ml ? `${p.ml} мл` : null),
    color_id:      window.productDetail.selectedColorId ?? p.color_id ?? null,
    color_name:    p.color ?? null,
    material_id:   window.productDetail.selectedMaterialId ?? p.material_id ?? null,
    material_name: p.material ?? null
  };
  addToCart(p, qty, opts);
}

/* ──────────────────────────────
 * СХОЖІ та ВАРІАНТИ
 * ────────────────────────────── */
const num = v => (v==null ? null : Number(v));
function similarScore(base, x) {
  let s = 0;
  if (num(base.subcategory_id) && num(x.subcategory_id) === num(base.subcategory_id)) s += 6;
  if (num(base.category_id)    && num(x.category_id)    === num(base.category_id))    s += 4;
  if (num(base.material_id)    && num(x.material_id)    === num(base.material_id))    s += 3;
  if (num(base.volume_id)      && num(x.volume_id)      === num(base.volume_id))      s += 2;
  if (base.ml && x.ml && Number(base.ml) === Number(x.ml))                             s += 1;
  if (base.diameter && x.diameter && String(base.diameter) === String(x.diameter))     s += 1;
  return s;
}
function computeSimilarProducts(base, list, limit = 12) {
  return (list||[])
    .filter(x => x && x.pos && x.pos !== base.pos)
    .map(x => [x, similarScore(base, x)])
    .filter(([_, s]) => s > 0)
    .sort((a,b) => b[1]-a[1])
    .slice(0, limit)
    .map(([x]) => x);
}
// ВАРІАНТИ «той самий товар, інший колір»
// ВАРІАНТИ «той самий товар, інший колір» (строгі критерії)
function computeColorVariants(base, list, limit = 14) {
  const num = v => (v == null ? null : Number(v));
  const norm = s => String(s || '').trim().toLowerCase();

  const extractNumber = s => {
    const m = String(s || '').match(/[\d.,]+/);
    return m ? Number(m[0].replace(',', '.')) : null;
  };

  // Прибираємо кольори/дужки з назви, щоб порівнювати "сутність" товару
  function normalizeTitle(t) {
    let s = String(t || '').toLowerCase();
    s = s.replace(/\(.*?\)/g, ''); // все в дужках
    s = s.replace(/(?:,|\s|-)?\s*(чорн(ий|а)|білий|рожев(ий|а)|син(ій|я)|зелений|червоний|black|white|pink|blue|green|red)\b/gi, '');
    s = s.replace(/\s+/g, ' ').trim();
    return s;
  }

  const baseTitle = normalizeTitle(base.title);
  const baseCat   = num(base.category_id);
  const baseSub   = num(base.subcategory_id);
  const baseVolId = num(base.volume_id);
  const baseMl    = base.ml != null ? Number(base.ml) : null;
  const baseVolN  = baseVolId || baseMl || extractNumber(base.volume);
  const baseDiaN  = extractNumber(base.diameter) ?? null;
  const baseMatId = num(base.material_id);
  const baseMat   = norm(base.material);

  const candidates = (list || []).filter(x => x && x.pos && x.pos !== base.pos);

  const filtered = candidates.filter(x => {
    // Назва
    if (normalizeTitle(x.title) !== baseTitle) return false;

    // Категорія / підкатегорія
    if (num(x.category_id) !== baseCat) return false;
    if (baseSub != null && num(x.subcategory_id) !== baseSub) return false;

    // Об'єм
    const xVolId = num(x.volume_id);
    const xMl    = x.ml != null ? Number(x.ml) : null;
    const xVolN  = xVolId || xMl || extractNumber(x.volume);
    if (baseVolN != null || xVolN != null) {
      if (xVolN == null || baseVolN == null) return false;
      if (Number(xVolN) !== Number(baseVolN)) return false;
    }

    // Діаметр
    const xDiaN = extractNumber(x.diameter);
    if (baseDiaN != null || xDiaN != null) {
      if (xDiaN == null || baseDiaN == null) return false;
      if (Number(xDiaN) !== Number(baseDiaN)) return false;
    }

    // Матеріал
    const xMatId = num(x.material_id);
    const xMat   = norm(x.material);
    if (baseMatId != null || xMatId != null) {
      if (xMatId == null || baseMatId == null) return false;
      if (xMatId !== baseMatId) return false;
    } else {
      if (xMat && baseMat && xMat !== baseMat) return false;
    }

    // Якщо сюди дійшли — це той самий товар (колір може відрізнятися)
    return true;
  });

  // Поточний товар першим
  const withBaseFirst = [base, ...filtered];

  // Унікальність по POS
  const seen = new Set();
  const uniq = withBaseFirst.filter(p => {
    if (seen.has(p.pos)) return false;
    seen.add(p.pos);
    return true;
  });

  return uniq.slice(0, limit);
}


/* ──────────────────────────────
 * ДЕТАЛІ ТОВАРУ (fallback)
 * Якщо інший скрипт уже оголосив window.openDetail — не перевизначаємо.
 * ────────────────────────────── */
async function ensureAllProducts() {
  if (ALL_PRODUCTS.length) return ALL_PRODUCTS;
  const { products } = await fetch('/api/products').then(r => r.json());
  ALL_PRODUCTS = products || [];
  return ALL_PRODUCTS;
}

if (typeof window.openDetail !== 'function') {
  window.openDetail = async function openDetail(pos) {
    try {
      const r = await fetch(`/api/products/${encodeURIComponent(pos)}`);
      if (!r.ok) throw new Error('Товар не знайдено');
      const { product } = await r.json();

      window.productDetail.current = product;
      window.productDetail.quantity = 1;
      window.productDetail.selectedVolumeId   = product.volume_id ?? null;
      window.productDetail.selectedColorId    = product.color_id ?? null;
      window.productDetail.selectedMaterialId = product.material_id ?? null;

      // Рекомендації з бекенда
      let recs = [];
      try {
        const rr = await fetch(`/api/recommendations/${encodeURIComponent(pos)}`).then(x => x.json());
        recs = rr.recommendations || [];
      } catch {}

      // Кеш каталогу + fallback-схожі
      await ensureAllProducts();
      const fallback = computeSimilarProducts(product, ALL_PRODUCTS, 12).filter(x => x.pos !== product.pos);
      const seen = new Set();
      const mergedRecs = [...recs, ...fallback].filter(p => { if (seen.has(p.pos)) return false; seen.add(p.pos); return true; }).slice(0,12);
      window.productDetail.recommendations = mergedRecs;

      // ВАРІАНТИ за кольором
      window.productDetail.variants = computeColorVariants(product, ALL_PRODUCTS, 14);

      // сигнал у сторінку: деталі готові (інлайн-скрипт index.html намалює модалку)
      document.dispatchEvent(new CustomEvent('detail:ready'));
    } catch (e) {
      console.error(e);
      alert('Не вдалося завантажити деталі товару.');
    }
  };
}

/* ──────────────────────────────
 * КАТАЛОГ + КАТЕГОРІЇ В ШАПЦІ
 * ────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();

  // викликаємо рендер категорій лише якщо він є і ще не виконувався
  if (typeof window.renderCategoriesNav === 'function' && !window.__catsRendered) {
    window.renderCategoriesNav().catch?.(console.error);
  }

  renderProducts().catch(console.error);
});

async function renderProducts(filterFn) {
  const grid = document.getElementById('products-grid');
  if (!grid) return;

  grid.innerHTML = '';
  const { products } = await fetch('/api/products').then(r => r.json());

  const list = typeof filterFn === 'function' ? products.filter(filterFn) : products;

  list.forEach((p, i) => {
    const sale = calcUnitPrice(p);
    const hasDiscount = Number(p.discount || 0) > 0;

    const card = document.createElement('div');

    // Скляна картка з делікатною анімацією наведення
    card.className = 'product-card group relative overflow-hidden bg-white/70 backdrop-blur-sm border border-white/30 rounded-xl shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 ease-out p-0';
    // Анімація появи (AOS)
    card.setAttribute('data-aos', 'fade-up');
    card.setAttribute('data-aos-delay', String((i % 6) * 40));

    const volLabel = p.volume || (p.ml ? `${p.ml} мл` : '—');
const colorHex = pickColorHex(p);
const colorDotStyle = colorHex
  ? `background:${colorHex};border-color:rgba(0,0,0,0.12);`
  : `background:linear-gradient(45deg,#ddd,#f5f5f5);border-color:rgba(0,0,0,0.15);`;

card.innerHTML = `
  <img src="${p.photos?.[0] || '/assets/img/placeholder.png'}" alt="${escapeHtml(p.title)}"
       class="w-full h-44 object-contain cursor-pointer rounded-t-xl transition-transform duration-300 ease-out group-hover:scale-105" data-pos="${p.pos}">
  <div class="p-4 flex flex-col">
    <h3 class="title mb-1.5 font-medium cursor-pointer line-clamp-2" data-pos="${p.pos}">${escapeHtml(p.title)}</h3>

    <!-- Чіпи характеристик -->
    <ul class="prod-specs">
      <!-- Матеріал -->
      <li class="spec-chip" title="Матеріал">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M10 3v5l-5 9a3 3 0 0 0 2.6 4.5h8.8A3 3 0 0 0 19 17l-5-9V3"/><path d="M8 3h8"/>
        </svg>
        <span>${escapeHtml(p.material || '—')}</span>
      </li>

      <!-- Діаметр -->
      <li class="spec-chip" title="Діаметр">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <circle cx="12" cy="12" r="6"/><path d="M8 12h8"/><path d="M8 12l-2 2M8 12l-2 -2"/><path d="M16 12l2 2M16 12l2 -2"/>
        </svg>
        <span>${escapeHtml(String(p.diameter ?? '—'))}</span>
      </li>

      <!-- Колір -->
      <li class="spec-chip" title="Колір">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M12 4a7 7 0 1 0 0 14h2.2a2.8 2.8 0 0 0 0-5.6H14"/><circle cx="8.5" cy="10" r="1.3"/><circle cx="12.5" cy="8" r="1.3"/><circle cx="14.5" cy="13.5" r="1.3"/>
        </svg>
        <span class="inline-flex items-center gap-1">
          <span class="spec-color-dot" style="${colorDotStyle}"></span>
          ${escapeHtml(p.color || '—')}
        </span>
      </li>

      <!-- Об’єм -->
      <li class="spec-chip" title="Об’єм">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M7 5h10v10a4 4 0 0 1-4 4h-2a4 4 0 0 1-4-4V5z"/><path d="M14 8h3M14 11h3"/>
        </svg>
        <span>${escapeHtml(volLabel)}</span>
      </li>
    </ul>

    <p class="price mb-2 font-bold">
      ₴${sale.toFixed(2)}
      ${hasDiscount ? `<span class="line-through text-gray-400 text-sm ml-2">₴${Number(p.price).toFixed(2)}</span>` : ''}
    </p>

    <div class="quantity-control flex items-center mb-2">
      <button class="qty-minus p-2 bg-gray-200 rounded transition-colors duration-200" data-pos="${p.pos}">−</button>
      <input type="number" class="qty-input mx-2 w-12 text-center border rounded" value="1" min="1" data-pos="${p.pos}">
      <button class="qty-plus  p-2 bg-gray-200 rounded transition-colors duration-200" data-pos="${p.pos}">＋</button>
    </div>
    <div class="flex items-center gap-2">
      <button class="add-to-cart btn-primary mt-auto" data-pos="${p.pos}">Додати в кошик</button>
      <span class="added-check hidden text-green-600 font-bold text-lg">✓</span>
    </div>
  </div>
`;


    grid.append(card);

    // Відкривати модалку ТІЛЬКИ при кліку на зображення чи заголовок
    card.querySelectorAll('img[data-pos], .title').forEach(el => {
      el.addEventListener('click', () => window.openDetail(p.pos));
    });

    // Контролі кількості
    const minus = card.querySelector('.qty-minus');
    const plus  = card.querySelector('.qty-plus');
    const input = card.querySelector('.qty-input');
    minus.addEventListener('click', () => { input.value = Math.max(1, Number(input.value) - 1); });
    plus.addEventListener('click',  () => { input.value = Number(input.value) + 1; });

    // Додати в кошик без модалки + показати галочку
    const addBtn = card.querySelector('.add-to-cart');
    const check  = card.querySelector('.added-check');
    addBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const qty = Number(input.value || 1);
      addToCart(p, qty);
      check.classList.remove('hidden');
      setTimeout(() => check.classList.add('hidden'), 1400);
    });
  });
}

/* ──────────────────────────────
 * КАТЕГОРІЇ (оголошуємо, якщо немає зовнішньої)
 * ────────────────────────────── */
function defineRenderCategoriesNav() {
  if (typeof window.renderCategoriesNav === 'function') return;

  window.renderCategoriesNav = async function renderCategoriesNav() {
    const nav   = document.getElementById('main-categories');
    const popup = document.getElementById('subcat-popup');
    if (!nav || !popup) return;

    const { categories } = await fetch('/api/categories').then(r => r.json());
    nav.innerHTML = '';

    // активна кнопка
    let activeBtn = null;
    const setActive = (btn) => {
      if (activeBtn) activeBtn.classList.remove('active');
      activeBtn = btn;
      if (btn) btn.classList.add('active');
    };

    // "Усі товари"
    const btnAll = document.createElement('button');
    btnAll.className = 'cat-btn px-3 py-1 rounded border hover:border-blue-500 hover:text-blue-600';
    btnAll.textContent = 'Усі товари';
    btnAll.addEventListener('click', (e) => {
      e.preventDefault();
      renderProducts();               // весь каталог
      setActive(btnAll);
      popup.classList.add('hidden');
      window.location.hash = '#products';
    });
    nav.append(btnAll);
    setActive(btnAll);

    // керування попапом
    let hideTimer = null;
    function scheduleHide() {
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => popup.classList.add('hidden'), 200);
    }
    popup.addEventListener('mouseenter', () => clearTimeout(hideTimer));
    popup.addEventListener('mouseleave', scheduleHide);

    function showPopupFor(btn, cat) {
      clearTimeout(hideTimer);

      const subs = cat.subcategories || [];
      popup.innerHTML = '';

      if (subs.length) {
        subs.forEach(sc => {
          const a = document.createElement('a');
          a.href = 'javascript:void(0)';
          a.className = 'block px-3 py-2 rounded hover:bg-gray-100';
          a.textContent = sc.name;
          a.addEventListener('click', () => {
            renderProducts(p => Number(p.subcategory_id) === Number(sc.id));
            setActive(btn);
            popup.classList.add('hidden');
            window.location.hash = '#products';
          });
          popup.append(a);
        });
      } else {
        const none = document.createElement('div');
        none.className = 'px-3 py-2 text-gray-500';
        none.textContent = 'Підкатегорій немає';
        popup.append(none);
      }

      const r = btn.getBoundingClientRect();
      popup.style.position = 'fixed';
      popup.style.left = `${Math.round(r.left)}px`;
      popup.style.top  = `${Math.round(r.bottom + 6)}px`;
      popup.style.minWidth = Math.max(160, r.width) + 'px';
      popup.style.zIndex = 60;
      popup.classList.remove('hidden');
    }

    // кнопки категорій
    (categories || []).forEach(cat => {
      const b = document.createElement('button');
      b.className = 'cat-btn px-3 py-1 rounded border hover:border-blue-500 hover:text-blue-600';
      b.textContent = cat.name;
      nav.append(b);

      // hover: показати попап (без зміни товарів)
      b.addEventListener('mouseenter', () => showPopupFor(b, cat));
      b.addEventListener('mouseleave', scheduleHide);

      const onActivate = (e) => {
        e.preventDefault();
        renderProducts(p => Number(p.category_id) === Number(cat.id));
        setActive(b);
        showPopupFor(b, cat);
        window.location.hash = '#products';
      };
      b.addEventListener('click', onActivate);
      b.addEventListener('touchstart', onActivate, { passive: false });
    });

    // клік поза попапом — ховаємо
    document.addEventListener('click', (e) => {
      if (!popup.classList.contains('hidden')) {
        if (!popup.contains(e.target) && !nav.contains(e.target)) {
          popup.classList.add('hidden');
        }
      }
    });
  };
}

/* ──────────────────────────────
 * УТИЛІТИ
 * ────────────────────────────── */
function escapeHtml(s) {
  return String(s ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;');
}

// Експорт корисних методів
window.updateCartCount = updateCartCount;
window.addToCart = addToCart;
window.addCurrentProductToCart = addCurrentProductToCart;
window.renderProducts = renderProducts;
window.getColorVariants = async function() {
  const p = window.productDetail.current || {};
  await ensureAllProducts();
  return computeColorVariants(p, ALL_PRODUCTS, 14);
};
