// assets/js/enhanced_interactions.js

// 1) Глобальні змінні
let cart        = JSON.parse(localStorage.getItem('banobox_cart') || '[]');
let allProducts = [];
let currentCat  = null;
let currentSub  = null;

let modalKeyHandler = null;   // слухач клавіш для модалки (стрілки/Esc)
let detailState = { photos: [], idx: 0, color: null };  // стан модалки

// 2) Ініціалізація після завантаження DOM
document.addEventListener('DOMContentLoaded', () => {
  // якщо на сторінці вже є renderCategoriesNav (з index.html) — НЕ викликаємо локальну
  if (typeof window.renderCategoriesNav !== 'function') {
    initCategoryNav(); // власна версія тільки як fallback
  }
  updateCartCount();
  loadProducts();
  bindModalBackdropClose();
});

// ────────────────────────────────────────────────────────────
// НАВІГАЦІЯ ЗА КАТЕГОРІЯМИ (легка версія; index може мати свою)
// ────────────────────────────────────────────────────────────
async function initCategoryNav() {
  try {
    const res = await fetch('/api/categories');
    const { categories } = await res.json();
    const nav = document.getElementById('main-categories');
    const popup = document.getElementById('subcat-popup');
    if (!nav || !popup) return;

    nav.innerHTML = '';

    // "Усі товари"
    const allBtn = document.createElement('button');
    allBtn.textContent = 'Усі товари';
    allBtn.className = 'cat-btn px-3 py-2 rounded bg-blue-600 text-white hover:opacity-90';
    allBtn.addEventListener('click', () => {
      currentCat = null; currentSub = null;
      hideSubcats();
      renderProducts();
    });
    nav.append(allBtn);

    categories.forEach(cat => {
      const btn = document.createElement('button');
      btn.textContent = cat.name;
      btn.className = 'cat-btn px-3 py-2 rounded hover:bg-gray-100';
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        currentCat = cat.name; currentSub = null;
        renderProducts();
        if (cat.subcategories?.length) showSubcats(cat.subcategories, btn, popup);
        else hideSubcats();
      });
      btn.addEventListener('mouseenter', () => {
        if (cat.subcategories?.length) showSubcats(cat.subcategories, btn, popup);
      });
      nav.append(btn);
    });

    // Закриття попапа по кліку поза ним
    document.addEventListener('click', (e) => {
      if (!popup.classList.contains('hidden')) {
        const insidePopup = popup.contains(e.target);
        const insideNav   = nav.contains(e.target);
        if (!insidePopup && !insideNav) popup.classList.add('hidden');
      }
    });
  } catch (e) {
    console.error('Помилка завантаження категорій:', e);
  }
}

function showSubcats(subcats, anchorBtn, popupEl) {
  const popup = popupEl || document.getElementById('subcat-popup');
  if (!popup) return;
  popup.innerHTML = '';
  subcats.forEach(sub => {
    const s = typeof sub === 'object' ? sub : { id: sub, name: sub };
    const b = document.createElement('button');
    b.textContent = s.name;
    b.className = 'block w-full text-left px-3 py-2 hover:bg-gray-100 rounded';
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      currentSub = s.name;
      popup.classList.add('hidden');
      renderProducts();
    });
    popup.append(b);
  });

  const r = anchorBtn.getBoundingClientRect();
  popup.style.position = 'fixed';
  popup.style.left = (r.left) + 'px';
  popup.style.top  = (r.bottom + 6) + 'px';
  popup.style.minWidth = Math.max(160, r.width) + 'px';
  popup.style.zIndex = 60;
  popup.classList.remove('hidden');
}
function hideSubcats() {
  const popup = document.getElementById('subcat-popup');
  if (popup) popup.classList.add('hidden');
}

// ────────────────────────────────────────────────────────────
/* КОШИК */
// ────────────────────────────────────────────────────────────
function saveCart() {
  localStorage.setItem('banobox_cart', JSON.stringify(cart));
  updateCartCount();
}
function updateCartCount() {
  const total = cart.reduce((s, i) => s + i.quantity, 0);
  document.querySelectorAll('.cart-count').forEach(el => el.textContent = total);
}
function addToCart(item, qty) {
  const idx = cart.findIndex(i => i.pos === item.pos && i.color === item.color);
  if (idx > -1) cart[idx].quantity += qty;
  else cart.push({ ...item, quantity: qty });
  saveCart();
}

// ────────────────────────────────────────────────────────────
/* ЗАВАНТАЖЕННЯ ТОВАРІВ */
// ────────────────────────────────────────────────────────────
async function loadProducts() {
  try {
    const res = await fetch('/api/products');
    const { products } = await res.json();
    allProducts = products || [];
    renderProducts();
  } catch(err) {
    console.error('Товари не завантажено:', err);
  }
}
function renderProducts() {
  let list = allProducts.slice();
  if (currentCat) list = list.filter(p => p.category === currentCat);
  if (currentSub) list = list.filter(p => p.subcategory === currentSub);
  renderProductCards(list);
}

// ────────────────────────────────────────────────────────────
/* КАРТКИ ТОВАРІВ */
// ────────────────────────────────────────────────────────────
function renderProductCards(products) {
  const grid = document.getElementById('products-grid');
  if (!grid) return;
  grid.innerHTML = '';

  products.forEach((p, i) => {
    const hasDiscount = Number(p.discount) > 0;
    const sale = hasDiscount
      ? (p.price * (100 - p.discount) / 100)
      : Number(p.price || 0);
    const badge = hasDiscount
      ? `<span class="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-red-100 text-red-700">-${p.discount}%</span>`
      : '';

    const card = document.createElement('div');
    // Скляна картка + плавна поява + підйом на ховері
    card.className = 'product-card group relative overflow-hidden bg-white/70 backdrop-blur-sm border border-white/30 rounded-xl shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 ease-out p-4';
    card.setAttribute('data-aos', 'fade-up');
    card.setAttribute('data-aos-delay', String((i % 6) * 40));

    card.innerHTML = `
      <img src="${(p.photos && p.photos[0]) || '/assets/img/placeholder.png'}"
           alt="${p.title || ''}"
           data-pos="${p.pos}"
           class="w-full h-44 object-contain mb-2 cursor-pointer rounded-t-xl transition-transform duration-300 ease-out group-hover:scale-105" />

      <h3 data-pos="${p.pos}" class="font-medium mb-1 cursor-pointer line-clamp-2">${p.title || ''}</h3>

      <p class="font-bold mb-2">₴${sale.toFixed(2)} ${badge}</p>

      <div class="flex items-center mb-3">
        <button class="qty-minus p-2 bg-gray-200 rounded transition-colors duration-200">−</button>
        <input type="number" class="qty-input mx-2 w-12 text-center border rounded" value="1" min="1">
        <button class="qty-plus p-2 bg-gray-200 rounded transition-colors duration-200">＋</button>
      </div>

      <button class="add-to-cart btn-primary mt-auto" data-pos="${p.pos}">Додати в кошик</button>
    `;

    grid.append(card);

    // Події
    card.querySelectorAll('[data-pos]').forEach(el => el.addEventListener('click', () => openDetail(el.dataset.pos)));

    const inp = card.querySelector('.qty-input');
    card.querySelector('.qty-minus').onclick = () => inp.value = Math.max(1, Number(inp.value) - 1);
    card.querySelector('.qty-plus').onclick  = () => inp.value = Number(inp.value) + 1;

    card.querySelector('.add-to-cart').onclick = e => {
      e.stopPropagation();
      addToCart({ pos: p.pos, color: p.color || null }, Number(inp.value));
    };
  });
}

// ────────────────────────────────────────────────────────────
/* ПЕЙДЖЕР КРАПОК ДЛЯ МОДАЛКИ */
// ────────────────────────────────────────────────────────────
function renderModalPager(modal){
  const dotsWrap = modal.querySelector('#modal-dots');
  if (!dotsWrap) return;
  dotsWrap.innerHTML = '';
  detailState.photos.forEach((src, i) => {
    const b = document.createElement('button');
    b.className = 'dot';
    b.type = 'button';
    b.setAttribute('aria-label', `Фото ${i+1}`);
    b.addEventListener('click', (e) => { e.stopPropagation(); setModalImage(modal, i); });
    dotsWrap.appendChild(b);
  });
  updateModalPager(modal);
}
function updateModalPager(modal){
  const dots = [...modal.querySelectorAll('#modal-dots .dot')];
  dots.forEach((d,i) => d.classList.toggle('active', i === detailState.idx));
  const counter = modal.querySelector('#modal-counter');
  if (counter) counter.textContent = `${detailState.idx + 1} / ${detailState.photos.length}`;
}
function setModalImage(modal, nextIdx){
  const total = detailState.photos.length || 1;
  detailState.idx = ((nextIdx % total) + total) % total; // кругова навігація
  const img = modal.querySelector('.modal-img');
  if (img) img.src = detailState.photos[detailState.idx];
  updateModalPager(modal);
}

// ────────────────────────────────────────────────────────────
/* ДЕТАЛЬНА МОДАЛКА */
// ────────────────────────────────────────────────────────────
async function openDetail(pos) {
  const modal = document.getElementById('detail-modal');
  if (!modal) return;

  try {
    let res = await fetch(`/api/products/${encodeURIComponent(pos)}`);
    if (res.status === 404) {
      const prod = allProducts.find(x => String(x.pos).toLowerCase() === String(pos).toLowerCase());
      if (prod?.id) res = await fetch(`/api/products/${encodeURIComponent(prod.id)}`);
    }
    if (!res.ok) throw new Error('Товар не знайдено');
    const { product } = await res.json();

    // Колір (для відображення та для cart-ключа)
    const displayColor = product.color || '-';
    const COLOR_MAP = {
      'рожевий': '#f472b6', 'чорний': '#111827', 'білий': '#ffffff',
      'синій': '#2563eb',  'зелений': '#10b981','червоний': '#ef4444'
    };
    const dot = modal.querySelector('.spec-color-dot');
    if (dot) {
      const key = String(displayColor || '').trim().toLowerCase();
      const hex = product.color_hex || COLOR_MAP[key];
      if (hex) {
        dot.style.backgroundColor = hex;
        dot.style.borderColor = 'rgba(0,0,0,0.12)';
      } else {
        dot.style.background = 'linear-gradient(45deg, #ddd, #f5f5f5)';
        dot.style.borderColor = 'rgba(0,0,0,0.15)';
      }
    }

    detailState.color  = displayColor;
    detailState.photos = Array.isArray(product.photos) && product.photos.length
      ? product.photos.slice()
      : ['/assets/img/placeholder.png'];
    detailState.idx    = 0;

    // Заповнення тексту/цін
    const sale = product.discount
      ? (product.price * (100 - product.discount) / 100).toFixed(2)
      : Number(product.price || 0).toFixed(2);

    modal.querySelector('.modal-img').src            = detailState.photos[0];
    modal.querySelector('.modal-title').textContent  = product.title || '';
    modal.querySelector('.modal-pos').textContent    = product.pos ? `POS: ${product.pos}` : '';
    const dEl   = modal.querySelector('.modal-discount');
    const oldEl = modal.querySelector('.modal-old-price');
    const prEl  = modal.querySelector('.modal-price');

    if (Number(product.discount) > 0) {
      dEl.textContent = `Знижка ${product.discount}%`;
      dEl.classList.remove('hidden');
      oldEl.textContent = `₴${Number(product.price || 0).toFixed(2)}`;
      oldEl.classList.remove('hidden');
    } else {
      dEl.classList.add('hidden');
      oldEl.classList.add('hidden');
    }
    prEl.textContent = `₴${sale}`;

    // Характеристики
    modal.querySelector('.modal-material').textContent  = product.material || '—';
    modal.querySelector('.modal-diameter').textContent  = product.diameter || '—';
    modal.querySelector('.modal-color').textContent     = displayColor;
    modal.querySelector('.modal-volume').textContent    = product.volume || (product.ml ? `${product.ml} мл` : '—');
    modal.querySelector('.modal-desc').textContent      = product.description || 'Опис відсутній';

    // Варіанти (мініатюри) — просте групування за початком назви
    const varsEl = modal.querySelector('.modal-variants');
    if (varsEl) {
      varsEl.innerHTML = '';
      const head = (product.title || '').split(' ')[0];
      const seen = new Set();
      [product, ...allProducts.filter(v => (v.title || '').startsWith(head))]
        .forEach(v => {
          if (seen.has(v.pos)) return; seen.add(v.pos);
          const el = document.createElement('button');
          el.className = 'variant-thumb' + (v.pos === product.pos ? ' selected' : '');
          el.innerHTML = `<img src="${(v.photos && v.photos[0]) || '/assets/img/placeholder.png'}" alt="${v.color || ''}" />`;
          el.title = v.color || '';
          el.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); if (v.pos !== product.pos) openDetail(v.pos); });
          varsEl.appendChild(el);
        });
    }

    // Рекомендації
    const recSec  = modal.querySelector('.modal-recommendations');
    const recList = recSec?.querySelector('.rec-list');
    if (recSec && recList) {
      let recs = [];
      try {
        const rres = await fetch(`/api/recommendations/${encodeURIComponent(product.pos)}`);
        if (rres.ok) recs = (await rres.json()).recommendations || [];
      } catch {}
      if (recs.length) {
        recSec.classList.remove('hidden');
        recList.innerHTML = '';
        recs.forEach(r => {
          const a = document.createElement('a');
          a.href = 'javascript:void(0)';
          a.className = 'min-w-[160px] bg-gray-50 rounded p-2 shadow hover:shadow-md transition';
          const rsale = r.discount ? (r.price*(100-r.discount)/100) : r.price;
          a.innerHTML = `
            <img src="${(r.photos && r.photos[0]) || '/assets/img/placeholder.png'}"
                 class="w-full h-24 object-cover rounded mb-2" alt="${r.title || ''}">
            <div class="text-sm font-medium">${r.title || ''}</div>
            <div class="text-xs text-gray-600">₴${Number(rsale || 0).toFixed(2)}</div>`;
          a.addEventListener('click', () => openDetail(r.pos));
          recList.appendChild(a);
        });
      } else {
        recSec.classList.add('hidden');
      }
    }

    // Кількість/додавання до кошика
    const qIn = modal.querySelector('.modal-qty');
    const btnMinus = modal.querySelector('.modal-qty-minus');
    const btnPlus  = modal.querySelector('.modal-qty-plus');
    const addBtn   = modal.querySelector('.modal-add-btn');
    const addMark  = modal.querySelector('.modal-add-check');

    if (qIn) qIn.value = 1;
    if (btnMinus) btnMinus.onclick = (e) => { e.stopPropagation(); qIn.value = Math.max(1, Number(qIn.value || 1) - 1); };
    if (btnPlus)  btnPlus.onclick  = (e) => { e.stopPropagation(); qIn.value = Number(qIn.value || 1) + 1; };
    if (addBtn)   addBtn.onclick   = (e) => {
      e.stopPropagation();
      addToCart({ pos: product.pos, color: displayColor }, Number(qIn?.value || 1));
      // легкий фідбек (галочка поруч з кнопкою)
      if (addBtn && addMark) {
        addBtn.disabled = true;
        const prev = addBtn.textContent;
        addBtn.textContent = 'Додано';
        addMark.classList.remove('opacity-0');
        setTimeout(() => {
          addMark.classList.add('opacity-0');
          addBtn.textContent = prev;
          addBtn.disabled = false;
        }, 1200);
      }
    };

    // Галерея: пейджер, стрілки, свайпи
    renderModalPager(modal);
    const prevBtn = modal.querySelector('#modal-prev');
    const nextBtn = modal.querySelector('#modal-next');
    if (prevBtn) prevBtn.onclick = (e) => { e.stopPropagation(); setModalImage(modal, detailState.idx - 1); };
    if (nextBtn) nextBtn.onclick = (e) => { e.stopPropagation(); setModalImage(modal, detailState.idx + 1); };

    // Свайп по фото
    const wrap = modal.querySelector('#modal-gallery');
    let sx = 0, sy = 0;
    if (wrap) {
      wrap.addEventListener('touchstart', e => {
        const t = e.changedTouches[0]; sx = t.clientX; sy = t.clientY;
      }, {passive:true});
      wrap.addEventListener('touchend', e => {
        const t = e.changedTouches[0]; const dx = t.clientX - sx; const dy = t.clientY - sy;
        if (Math.abs(dx) > 30 && Math.abs(dx) > Math.abs(dy)) {
          if (dx < 0) setModalImage(modal, detailState.idx + 1);
          else        setModalImage(modal, detailState.idx - 1);
        }
      }, {passive:true});
    }

    // Клавіші
    if (modalKeyHandler) {
      document.removeEventListener('keydown', modalKeyHandler);
      modalKeyHandler = null;
    }
    modalKeyHandler = (e) => {
      if (modal.classList.contains('hidden')) return;
      if (e.key === 'Escape')      closeModal();
      if (e.key === 'ArrowRight')  setModalImage(modal, detailState.idx + 1);
      if (e.key === 'ArrowLeft')   setModalImage(modal, detailState.idx - 1);
    };
    document.addEventListener('keydown', modalKeyHandler);

    // Показати модалку
    modal.classList.remove('hidden');

  } catch(err) {
    console.error(err);
    alert('Не вдалося завантажити деталі товару.');
  }
}

function closeModal() {
  const modal = document.getElementById('detail-modal');
  if (modal) modal.classList.add('hidden');
  if (modalKeyHandler) {
    document.removeEventListener('keydown', modalKeyHandler);
    modalKeyHandler = null;
  }
}

function bindModalBackdropClose() {
  const modal = document.getElementById('detail-modal');
  if (!modal) return;
  modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
}
