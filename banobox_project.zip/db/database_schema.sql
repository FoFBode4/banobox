-- db/database_schema.sql


-- Active: 1754218969240@@127.0.0.1@3306
-- Банковок: схема БД SQLite

-- Користувачі
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Категорії
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);

-- Підкатегорії
CREATE TABLE IF NOT EXISTS subcategories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  UNIQUE(category_id, name)
);

-- Об’єми
CREATE TABLE IF NOT EXISTS volumes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subcategory_id INTEGER NOT NULL REFERENCES subcategories(id) ON DELETE CASCADE,
  volume TEXT NOT NULL,
  UNIQUE(subcategory_id, volume)
);

PRAGMA foreign_keys = OFF;
BEGIN TRANSACTION;

-- 1) Перейменовуємо поточну таблицю
ALTER TABLE volumes RENAME TO volumes_old;

-- 2) Створюємо нову таблицю з тим же набором стовпців,
--    але без NOT NULL на subcategory_id:
CREATE TABLE volumes (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  subcategory_id INTEGER REFERENCES subcategories(id) ON DELETE CASCADE,
  volume         TEXT NOT NULL,
  UNIQUE(subcategory_id, volume)
);

-- 3) Копіюємо дані зі старої в нову
INSERT INTO volumes (id, subcategory_id, volume)
SELECT id, subcategory_id, volume
FROM volumes_old;

-- 4) Видаляємо тимчасову таблицю
DROP TABLE volumes_old;

COMMIT;
PRAGMA foreign_keys = ON;





-- Дозволяємо зовнішні ключі
PRAGMA foreign_keys = OFF;
BEGIN TRANSACTION;

-- 1) Додаємо новий стовпець, який за замовчуванням буде NULL,
-- і одразу вказуємо, що це FOREIGN KEY до categories(id).
ALTER TABLE volumes
  ADD COLUMN category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL;

COMMIT;
PRAGMA foreign_keys = ON;

UPDATE volumes
SET category_id = NULL
WHERE id = 4;



-- Кольори
CREATE TABLE IF NOT EXISTS colors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  volume_id INTEGER NOT NULL REFERENCES volumes(id) ON DELETE CASCADE,
  color_name TEXT NOT NULL,
  UNIQUE(volume_id, color_name)
);

-- Товари
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pos TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  price REAL NOT NULL,
  discount INTEGER DEFAULT 0,
  material TEXT,
  diameter TEXT,
  dosage TEXT,
  volume_id INTEGER REFERENCES volumes(id),
  color_id INTEGER REFERENCES colors(id),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Фото товарів
CREATE TABLE IF NOT EXISTS product_photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url TEXT NOT NULL
);

-- Замовлення
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id),
  customer_name TEXT,
  customer_phone TEXT,
  customer_messenger TEXT,
  city TEXT,
  branch TEXT,
  comment TEXT,
  total REAL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Позиції замовлення
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  color_id INTEGER REFERENCES colors(id),
  volume_id INTEGER REFERENCES volumes(id)
);

-- Сесії (для express-session)
CREATE TABLE IF NOT EXISTS sessions (
  sid TEXT PRIMARY KEY,
  sess TEXT NOT NULL,
  expire DATETIME NOT NULL
);


-- Додаємо основні категорії
INSERT INTO categories(name) VALUES
  ('Флакони'),
  ('Баночки'),
  ('Комплектуючі');

  INSERT INTO categories(name) VALUES
  ('Дропери');

   -- Об’єми для Дроперів
INSERT INTO volumes(category_id, volume)
VALUES
  (
    (SELECT id FROM categories WHERE name = 'Дропери'),
    '10 мл'
  ),
  (
    (SELECT id FROM categories WHERE name = 'Дропери'),
    '15 мл'
  ),
  (
    (SELECT id FROM categories WHERE name = 'Дропери'),
    '30 мл'
  ),
  (
    (SELECT id FROM categories WHERE name = 'Дропери'),
    '50 мл'
  ),
  (
    (SELECT id FROM categories WHERE name = 'Дропери'),
    '100 мл'
  );

DELETE FROM volumes
WHERE category_id = (
    SELECT id FROM categories WHERE name = 'Дропери'
)
AND id NOT IN (
    SELECT MIN(id)
    FROM volumes
    WHERE category_id = (
        SELECT id FROM categories WHERE name = 'Дропери'
    )
    GROUP BY volume
);
INSERT INTO colors(volume_id,color_name)
VALUES
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='10 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='15 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='30 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='50 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='100 мл'),'Білий'),
    ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='10 мл'),'Чорний'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='15 мл'),'Чорний'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='30 мл'),'Чорний'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='50 мл'),'Чорний'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='100 мл'),'Чорний'),
    ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='10 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='15 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='30 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='50 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='100 мл'),'Помаранчевий'),
    ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='10 мл'),'Золотий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='15 мл'),'Золотий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='30 мл'),'Золотий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='50 мл'),'Золотий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='100 мл'),'Золотий'),
    ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='10 мл'),'Сріблястий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='15 мл'),'Сріблястий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='30 мл'),'Сріблястий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='50 мл'),'Сріблястий'),
  ((SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='100 мл'),'Сріблястий');


  


-- Підкатегорії для Флаконів
INSERT INTO subcategories(category_id,name)
VALUES
  ((SELECT id FROM categories WHERE name='Флакони'),'Пластикові'),
  ((SELECT id FROM categories WHERE name='Флакони'),'Скляні');

-- Об’єми для пластикових флаконів
INSERT INTO volumes(subcategory_id,volume)
VALUES
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Пластикові'),'50 мл'),
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Пластикові'),'100 мл'),
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Пластикові'),'150 мл');


INSERT INTO volumes(subcategory_id,volume)
VALUES
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Скляні'),'30 мл'),
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Скляні'),'50 мл'),
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Скляні'),'100 мл'),
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Скляні'),'150 мл');

INSERT INTO colors(volume_id,color_name)
VALUES
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),'Бирюзо'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),'Прозорий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),'Синій'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),'Чорний'),
    ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='50 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='50 мл'),'Бирюзо'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='50 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='50 мл'),'Прозорий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='50 мл'),'Синій'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='50 мл'),'Чорний'),
    ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='100 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='100 мл'),'Бирюзо'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='100 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='100 мл'),'Прозорий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='100 мл'),'Синій'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='100 мл'),'Чорний'),
    ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='150 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='150 мл'),'Бирюзо'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='150 мл'),'Помаранчевий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='150 мл'),'Прозорий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='150 мл'),'Синій'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='150 мл'),'Чорний');


INSERT INTO products(pos,title,price,discount,material,diameter,description,volume_id,color_id)
VALUES(
  'whilepp30ml',
  'Дропер Білий 30',
  10,
  0,
  'Скло',
  '20 мм',
  'Дропер Білий для пляшок 30мм.',
  (SELECT v.id FROM volumes v JOIN categories s ON v.category_id=s.id WHERE s.name='Дропери' AND v.volume='30 мл'),
  (SELECT c.id FROM colors c JOIN volumes v ON c.volume_id=v.id WHERE v.volume='30 мл' AND c.color_name='Білий')
);

INSERT INTO product_photos(product_id,url)
VALUES(
  (SELECT id FROM products WHERE pos='whilepp30ml'),
  '/img/whilepp30ml.png'
);





INSERT INTO volumes(subcategory_id,volume)
VALUES
  ((SELECT s.id FROM subcategories s JOIN categories c ON s.category_id=c.id WHERE c.name='Флакони' AND s.name='Пластикові'),'150 мл');
-- Кольори для 50 мл пластикових флаконів
INSERT INTO colors(volume_id,color_name)
VALUES
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Пластикові' AND v.volume='50 мл'),'Білий'),
  ((SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Пластикові' AND v.volume='50 мл'),'Чорний');



ALTER TABLE products
ADD COLUMN description TEXT;

UPDATE products
SET description = 'Тут опис товару..ЬДІВТМ ІВОТАОІВ.' 
WHERE pos = 'F-UA-050-WH';



-- Приклад товару: пластиковий флакон 50 мл білий
INSERT INTO products(pos,title,price,discount,material,diameter,volume_id,color_id)
VALUES(
  'F-UA-050-WH',
  'Флакон пластиковий 50 мл Білий',
  8,
  5,
  'Пластик',
  '20 мм',
  (SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Пластикові' AND v.volume='50 мл'),
  (SELECT c.id FROM colors c JOIN volumes v ON c.volume_id=v.id WHERE v.volume='50 мл' AND c.color_name='Білий')
);

INSERT INTO products(pos,title,price,discount,material,diameter,description,volume_id,color_id)
VALUES(
  'proz30mll',
  'Флакон скляний 30мл Прощорий',
  15,
  0,
  'Скло',
  '20 мм',
  'Флакон скляний 30 мл прозорий з діаметром 20.',
  (SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),
  (SELECT c.id FROM colors c JOIN volumes v ON c.volume_id=v.id WHERE v.volume='30 мл' AND c.color_name='Прозорий')
);
INSERT INTO product_photos(product_id,url)
VALUES(
  (SELECT id FROM products WHERE pos='proz30mll'),
  '/img/proz30ml.png'
);



INSERT INTO products(pos,title,price,discount,material,diameter,description,volume_id,color_id)
VALUES(
  'bz30mll',
  'Флакон скляний 30мл Бирюзовий',
  15,
  0,
  'Скло',
  '20 мм',
  'Флакон скляний 30 мл бирюзовий з діаметром 20.',
  (SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),
  (SELECT c.id FROM colors c JOIN volumes v ON c.volume_id=v.id WHERE v.volume='30 мл' AND c.color_name='Бирюзо')
);
INSERT INTO product_photos(product_id,url)
VALUES(
  (SELECT id FROM products WHERE pos='bz30mll'),
  '/img/bz30ml.png'
);

INSERT INTO products(pos,title,price,discount,material,diameter,description,volume_id,color_id)
VALUES(
  'pm30mll',
  'Флакон скляний 30мл Помаранчевий',
  15,
  0,
  'Скло',
  '20 мм',
  'Флакон скляний 30 мл помаранчевий з діаметром 20.',
  (SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Скляні' AND v.volume='30 мл'),
  (SELECT c.id FROM colors c JOIN volumes v ON c.volume_id=v.id WHERE v.volume='30 мл' AND c.color_name='Помаранчевий')
);
INSERT INTO product_photos(product_id,url)
VALUES(
  (SELECT id FROM products WHERE pos='pm30mll'),
  '/img/pm30ml.png'
);



DELETE FROM products
WHERE pos IN ('proz30ml', 'bz30ml', 'pm30ml');
DELETE FROM product_photos
WHERE product_id NOT IN (SELECT id FROM products);





-- Додаємо зображення до продукту
INSERT INTO product_photos(product_id,url)
VALUES(
  (SELECT id FROM products WHERE pos='F-UA-050-WH'),
  '/img/F-UA-050-WH.png'
);

INSERT INTO products(pos,title,price,discount,material,diameter,volume_id,color_id)
VALUES(
  'F-UA-050-WH',
  'Флакон пластиковий 50 мл Білий',
  8.2,
  10,
  'Пластик',
  '20 мм',
  (SELECT v.id FROM volumes v JOIN subcategories s ON v.subcategory_id=s.id WHERE s.name='Пластикові' AND v.volume='50 мл'),
  (SELECT c.id FROM colors c JOIN volumes v ON c.volume_id=v.id WHERE v.volume='50 мл' AND c.color_name='Білий')
);


UPDATE product_photos
SET url = '/img/F-PL-050-WH.png'
WHERE product_id = (
  SELECT id FROM products WHERE pos = 'F-PL-050-WH'
);




-- Видаляємо фото з product_photos
DELETE FROM product_photos
WHERE product_id = (
  SELECT id FROM products WHERE pos = 'F-UA-050-WH'
);

-- Видаляємо позицію в order_items, якщо така є
DELETE FROM order_items
WHERE product_id = (
  SELECT id FROM products WHERE pos = 'F-UA-050-WH'
);

-- Видаляємо сам товар
DELETE FROM products
WHERE pos = 'F-UA-050-WH';


UPDATE products
SET description = 'Бомбезний товар.' 
WHERE pos = 'D012';




ALTER TABLE products ADD COLUMN category_id    INTEGER;
ALTER TABLE products ADD COLUMN subcategory_id INTEGER;
-- Оберіть id потрібної категорії та підкатегорії:
SELECT id FROM categories    WHERE name = 'Флакони';
SELECT id FROM subcategories WHERE name = 'Пластикові';

-- Приклад оновлення для кількох POS:
UPDATE products
   SET category_id    = (SELECT id FROM categories    WHERE name='Флакони'),
       subcategory_id = (SELECT id FROM subcategories WHERE name='Пластикові')
 WHERE pos IN ('D012','F-UA-050-WH');
SELECT id FROM subcategories WHERE name = 'Скляні';

UPDATE products
   SET category_id    = (SELECT id FROM categories    WHERE name='Флакони'),
       subcategory_id = (SELECT id FROM subcategories WHERE name='Скляні')
 WHERE pos IN ('proz30mll','bz30mll', 'pm30mll');


 SELECT id FROM categories    WHERE name = 'Дропери';

 UPDATE products
   SET category_id    = (SELECT id FROM categories    WHERE name='Дропери')
 WHERE pos IN ('whilepp30ml');